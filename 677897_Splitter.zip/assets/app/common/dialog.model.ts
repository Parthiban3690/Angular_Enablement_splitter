export class DialogModel {
    constructor(public title: string, public content: string) {}
}